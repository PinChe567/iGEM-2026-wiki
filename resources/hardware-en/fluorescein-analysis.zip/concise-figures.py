"""Concise displays of unchanged DLIA and session-transfer source results."""
from pathlib import Path
import csv
import importlib.util
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
STUDY = HERE.parent
PRIOR = STUDY.parent / "fluorescein_2026-10-19"
spec = importlib.util.spec_from_file_location(
    "original_analysis", STUDY / "code" / "analyze_fluorescein.py")
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
COLORS = original.COLORS
FREQ = original.FREQ
LABELS = ["D1", "D2", "D3", "D4"]
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10,
    "axes.titlesize": 12, "axes.labelsize": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "svg.fonttype": "none", "svg.hashsalt": "aerosense-concise-readout-v1",
})


def save(fig, stem):
    fig.savefig(HERE / f"{stem}.svg", bbox_inches="tight",
                metadata={"Date": None})
    fig.savefig(HERE / f"{stem}.png", dpi=180, bbox_inches="tight")
    svg = HERE / f"{stem}.svg"
    svg.write_text(svg.read_text(encoding="utf-8").replace(
        "'DejaVu Sans'", "'DejaVu Sans', Arial, sans-serif"), encoding="utf-8")
    plt.close(fig)


def main():
    records = original.load(STUDY / "raw")
    previous = original.load(PRIOR / "raw")
    groups = {g: [r for r in records if r["group"] == g]
              for g in original.GROUPS}
    blank = np.mean([r["z"] for r in groups["DDW"]], axis=0)
    means = np.array([np.mean([r["z"] for r in groups[g]], axis=0)
                      for g in original.GROUPS])
    single = np.array([
        np.mean([r["z"] for r in records if r["group"] == f"D{i}-100C"],
                axis=0) - blank for i in range(1, 5)]).T
    phase = np.diag(single) / abs(np.diag(single))
    # Same rule as the archived figure: first recorded uniform 10 µM standard.
    record = groups["100C"][0]
    voltage, t = record["v"], record["t"]
    net = np.real((record["z"] - blank) * np.conj(phase))
    fig, axes = plt.subplots(2, 2, figsize=(10.7, 7.3), layout="constrained")
    window = t <= .15
    axes[0, 0].plot(t[window], voltage[window], lw=.9, color="#246680")
    axes[0, 0].set(xlabel="Time (s)", ylabel="ADC voltage (mV)",
                   title="A  Photodiode waveform")
    spectrum = 2 / len(voltage) * abs(np.fft.rfft(voltage - voltage.mean()))
    frequency = np.fft.rfftfreq(len(voltage), 1 / 4000)
    axes[0, 1].plot(frequency, spectrum, color="#8a9ca6", lw=.9)
    for j, f in enumerate(FREQ):
        value = spectrum[np.argmin(abs(frequency - f))]
        axes[0, 1].plot(f, value, "o", color=COLORS[j], ms=5)
        axes[0, 1].annotate(f"D{j+1}", (f, value), xytext=(0, 8),
                            textcoords="offset points", ha="center",
                            color=COLORS[j], fontsize=10)
    axes[0, 1].set(xlim=(25, 130), ylim=(0, spectrum[
        (frequency >= 25) & (frequency <= 130)].max() * 1.23),
        xticks=FREQ, xlabel="Frequency (Hz)", ylabel="Amplitude (mV)",
        title="B  Frequency separation")
    ticks = np.arange(400, 8001, 100)
    for j, f in enumerate(FREQ):
        running = 2 / ticks * (
            np.cumsum((voltage - voltage.mean()) *
                      np.cos(2 * np.pi * f * t))[ticks - 1] +
            1j * np.cumsum((voltage - voltage.mean()) *
                           np.sin(2 * np.pi * f * t))[ticks - 1])
        axes[1, 0].plot(ticks / 4000, abs(running), color=COLORS[j],
                        label=LABELS[j], lw=1.5)
    axes[1, 0].set(xlabel="Integration time (s)", ylabel="Amplitude (mV)",
                   title="C  Lock-in extraction")
    axes[1, 0].legend(ncol=4, frameon=False, fontsize=9)
    xx = np.arange(4)
    axes[1, 1].bar(xx - .18, abs(record["z"]), .36, color="#b2c0c9",
                   label="Raw carrier")
    axes[1, 1].bar(xx + .18, net, .36, color=COLORS,
                   label="Blank-corrected")
    axes[1, 1].set(xticks=xx, xticklabels=LABELS, ylabel="Response (mV)",
                   title="D  Water subtraction")
    axes[1, 1].legend(frameon=False, fontsize=9)
    save(fig, "concise-dlia")

    old_groups = {g: [r for r in previous if r["group"] == g]
                  for g in ["DDW", "10C", "100C"]}
    old_blank = np.mean([r["z"] for r in old_groups["DDW"]], axis=0)
    old10 = np.mean([r["z"] for r in old_groups["100C"]], axis=0) - old_blank
    old1 = np.mean([r["z"] for r in old_groups["10C"]], axis=0) - old_blank
    gain = (means[4] - blank) / old10
    aligned1 = (means[1] - blank) / gain
    error = abs(aligned1 - old1)
    with (STUDY / "derived" / "session_transfer_holdout.csv").open(
            newline="", encoding="utf-8-sig") as stream:
        archived = list(csv.DictReader(stream))
    assert np.allclose(error, [
        float(row["absolute_complex_error_mV"]) for row in archived], atol=1e-12)
    fig, axes = plt.subplots(1, 2, figsize=(10.3, 4.3), layout="constrained")
    for j in range(4):
        axes[0].plot([j - .15, j + .15], [abs(old1[j]), abs(aligned1[j])],
                     color=COLORS[j], alpha=.7, lw=1.5)
        axes[0].scatter(j - .15, abs(old1[j]), color=COLORS[j], marker="o",
                        s=70, facecolors="white", linewidths=1.7,
                        label="Previous" if j == 0 else None)
        axes[0].scatter(j + .15, abs(aligned1[j]), color=COLORS[j], marker="s",
                        s=58, label="Aligned current" if j == 0 else None)
    axes[0].set(xticks=xx, xticklabels=LABELS, ylim=(0, None),
                 ylabel="Response (mV)", title="A  1 µM transfer check")
    axes[0].legend(frameon=False, fontsize=9)
    axes[1].bar(xx, error, color=COLORS, width=.55)
    axes[1].set(xticks=xx, xticklabels=LABELS, ylim=(0, 3.65),
                 ylabel="Complex residual magnitude (mV)",
                 title="B  Alignment residual")
    for j in range(4):
        axes[1].text(j, error[j] + .09, f"{error[j]:.2f}",
                     ha="center", va="bottom", fontsize=10)
    save(fig, "concise-session-transfer")
    proof = {
        "dlia_record_id": record["id"],
        "dlia_source_group": record["group"],
        "dlia_sample_rate_Hz": 4000,
        "dlia_samples": 8000,
        "frequencies_Hz": FREQ.tolist(),
        "records_verified": len(records),
        "iq_max_error_V": max(r["error_V"] for r in records),
        "saved_session_transfer_csv_verified": True,
        "session_transfer_previous_1uM_mV": abs(old1).tolist(),
        "session_transfer_aligned_1uM_mV": abs(aligned1).tolist(),
        "session_transfer_complex_error_mV": error.tolist(),
    }
    (HERE / "concise-figures-proof.json").write_text(
        json.dumps(proof, indent=2), encoding="utf-8")
    print(json.dumps(proof, indent=2))


if __name__ == "__main__":
    main()
