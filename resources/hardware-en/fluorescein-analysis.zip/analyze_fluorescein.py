"""Reproduce the expanded sodium-fluorescein series without altering raw data.

One independently prepared loading per condition, three technical reads.
Outputs distinguish training fits, concentration-level holdouts, and repeat-read
checks. The two-second ADC trace measures modulation frequency, not wavelength.
"""
from pathlib import Path
import argparse, csv, io, json, itertools, hashlib
import numpy as np
from scipy.optimize import least_squares, nnls, brentq
from scipy.interpolate import PchipInterpolator
from scipy.stats import rankdata
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

COLORS = ["#246680", "#bb6843", "#5a8a65", "#9162a0"]
FREQ = np.array([41, 67, 89, 113])
LEVELS = np.array([0, 1, 2.5, 5, 10, 20.])
GROUPS = ["DDW", "10C", "25C", "50C", "100C", "200C"]


def clean(x):
    if isinstance(x, dict): return {k: clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple, np.ndarray)): return [clean(v) for v in x]
    if isinstance(x, np.generic): return clean(x.item())
    if isinstance(x, complex): return {"real": x.real, "imag": x.imag}
    if isinstance(x, float) and not np.isfinite(x): return None
    return x


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)


def z_of(r):
    return 1000 * (np.array(r["inPhaseV"]) + 1j*np.array(r["quadratureV"]))


def load(folder):
    records = []
    for p in sorted(folder.glob("*_report_*.json"), key=lambda p:int(p.stem.rsplit("-",1)[1])):
        d = json.loads(p.read_text("utf-8-sig")); r = d["records"][0]
        cp = p.with_name(p.name.replace("_report_", "_raw_")).with_suffix(".csv")
        table = np.genfromtxt(io.StringIO(cp.read_text("utf-8-sig")), delimiter=",", names=True,
                              dtype=None, encoding="utf-8")
        v = table["adc_counts"]*2.5/65536*1000
        n = len(v); t = (np.arange(n)+1)/r["sampleRateHz"]
        computed = 2/n*(np.cos(2*np.pi*FREQ[:,None]*t)@(v-v.mean())+
                         1j*np.sin(2*np.pi*FREQ[:,None]*t)@(v-v.mean()))
        assert n == 8000 and r["sampleRateHz"] == 4000
        assert r["frequenciesHz"] == list(FREQ) and r["dutyPercent"] == 25
        assert r["valid"] and not r["timingFault"] and r["railSamples"] == 0
        assert np.max(abs(computed-z_of(r))) < 1e-5
        embedded = list(csv.DictReader(io.StringIO(r["rawCsv"])))
        assert np.array_equal([int(x["adc_counts"]) for x in embedded], table["adc_counts"])
        r.update(z=z_of(r), v=v, t=t, group=r["conditionTag"][:-1], file=p.name,
                 error_V=float(np.max(abs(computed-z_of(r)))/1000),
                 saved_blank=np.mean([z_of(b) for b in d["measuredCalibration"]["blank"]],axis=0))
        records.append(r)
    return records


def fit_model(x,y,name):
    scale=20.
    if name in ["Linear","Quadratic","Cubic"]:
        degree={"Linear":1,"Quadratic":2,"Cubic":3}[name]
        p=np.polynomial.polynomial.polyfit(x/scale,y,degree)
        return lambda xx:np.polynomial.polynomial.polyval(np.asarray(xx)/scale,p), p
    if name=="PCHIP":
        f=PchipInterpolator(x,y,extrapolate=False)
        return f, np.array([])
    def formula(p,xx):
        u=np.asarray(xx)/scale
        if name=="Power": return p[0]+p[1]*u**p[2]
        k=p[2]
        ratio=u if abs(k)<1e-6 else np.expm1(k*u)/np.expm1(k)
        return p[0]+p[1]*ratio
    bounds=([-np.inf,0,0.1],[np.inf,np.inf,5]) if name=="Power" else ([-np.inf,0,-8],[np.inf,np.inf,8])
    starts=[.5,1,2,4] if name=="Power" else [-2,.1,2,5]
    candidates=[least_squares(lambda p:formula(p,x)-y,[float(y[0]),max(float(y[-1]-y[0]),.01),k],
                             bounds=bounds,max_nfev=4000) for k in starts]
    result=min(candidates,key=lambda r:np.sum(r.fun**2))
    return lambda xx:formula(result.x,xx),result.x


def inverse(f,value,upper=20):
    grid=np.linspace(0,upper,4001); vals=f(grid)-value
    roots=list(grid[np.isclose(vals,0,atol=1e-9,rtol=0)])
    roots += [brentq(lambda x:float(f(x)-value),grid[i],grid[i+1])
              for i in np.where(vals[:-1]*vals[1:]<0)[0]]
    unique=[]
    for r in sorted(roots):
        if not unique or abs(r-unique[-1])>1e-5: unique.append(r)
    return (unique[0] if len(unique)==1 else np.nan),len(unique)


def holm(ps):
    order=np.argsort(ps); out=np.empty(len(ps)); prev=0
    for k,i in enumerate(order):
        prev=max(prev,min(1,(len(ps)-k)*ps[i]));out[i]=prev
    return out


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--data-root",type=Path,required=True)
    parser.add_argument("--previous-root",type=Path,required=True)
    parser.add_argument("--preview-dir",type=Path,required=True)
    parser.add_argument("--simulation",type=Path)
    a=parser.parse_args()
    out=a.data_root/"derived"; figs=a.data_root/"figures"
    for p in [out,figs,a.preview_dir]:p.mkdir(parents=True,exist_ok=True)
    rs=load(a.data_root/"raw"); assert len(rs)==30
    old=load(a.previous_root/"raw")
    groups={g:[r for r in rs if r["group"]==g] for g in GROUPS+[f"D{i}-100C" for i in range(1,5)]}
    blank=np.mean([r["z"] for r in groups["DDW"]],axis=0)
    means=np.array([np.mean([r["z"] for r in groups[g]],axis=0) for g in GROUPS])
    # Phase direction from all uniform standards. LOCO refits this direction below.
    slope=np.linalg.lstsq(np.c_[np.ones(6),LEVELS],means,rcond=None)[0][1]
    phase=slope/abs(slope)
    for r in rs:
        r["y"]=np.real((r["z"]-blank)*np.conj(phase))
    ym=np.array([np.mean([r["y"] for r in groups[g]],axis=0) for g in GROUPS])
    ys=np.array([np.std([r["y"] for r in groups[g]],axis=0,ddof=1) for g in GROUPS])
    rows=[]
    for r in rs:
        for j in range(4):
            rows.append(dict(record_id=r["id"],source_label=r["conditionTag"],group=r["group"],
                             channel=f"D{j+1}",frequency_Hz=FREQ[j],raw_I_mV=r["z"][j].real,
                             raw_Q_mV=r["z"][j].imag,signed_blank_corrected_mV=r["y"][j],
                             magnitude_blank_corrected_mV=abs(r["z"][j]-blank[j]),
                             old_blank_magnitude_mV=abs(r["z"][j]-r["saved_blank"][j]),
                             device_midpoint_s=r["deviceTimeMs"]/1000))
    write_csv(out/"channel_measurements.csv",rows)
    write_csv(out/"acquisition_checks.csv",[dict(record_id=r["id"],samples=r["samples"],
               iq_recomputation_error_V=r["error_V"],adc_min=r["adcMin"],adc_max=r["adcMax"],
               rail_samples=r["railSamples"],max_interval_error_us=r["maxIntervalErrorUs"]) for r in rs])
    models=["Linear","Quadratic","Cubic","Exponential","Power","PCHIP"]
    modelrows=[]; cvrows=[]; funcs={}
    for j in range(4):
        for name in models:
            f,pars=fit_model(LEVELS,ym[:,j],name);funcs[j,name]=f
            monotonic=bool(np.all(np.diff(f(np.linspace(0,20,2001)))>0))
            forward=[]; inverse_errors=[];valid=0
            for held in range(1,5):
                keep=np.arange(6)!=held
                # Calibration direction and blank estimated without held level.
                bs=np.linalg.lstsq(np.c_[np.ones(5),LEVELS[keep]],means[keep],rcond=None)[0][1,j]
                ph=bs/abs(bs)
                train=np.real((means[keep,j]-blank[j])*np.conj(ph))
                test=np.real((means[held,j]-blank[j])*np.conj(ph))
                cf,_=fit_model(LEVELS[keep],train,name)
                pred,nroot=inverse(cf,test)
                err=float(cf(LEVELS[held])-test);forward.append(err)
                if np.isfinite(pred):valid+=1;inverse_errors.append(pred-LEVELS[held])
                cvrows.append(dict(channel=f"D{j+1}",model=name,held_concentration_uM=LEVELS[held],
                              observed_mV=test,predicted_mV=float(cf(LEVELS[held])),forward_error_mV=err,
                              inverse_uM=pred,number_of_roots=nroot))
            modelrows.append(dict(channel=f"D{j+1}",model=name,monotonic=monotonic,
                  training_rmse_mV=float(np.sqrt(np.mean((f(LEVELS)-ym[:,j])**2))),
                  level_holdout_rmse_mV=float(np.sqrt(np.mean(np.array(forward)**2))),
                  unique_inverse_levels=valid,inverse_level_rmse_uM=float(np.sqrt(np.mean(np.array(inverse_errors)**2))) if valid else np.nan,
                  parameters=json.dumps(pars.tolist())))
    write_csv(out/"model_comparison.csv",modelrows);write_csv(out/"concentration_level_holdouts.csv",cvrows)
    # Exact permutation tests on SIX loading means, not 18 independent samples.
    permutations=np.array(list(itertools.permutations(range(6))))
    stats=[]
    for j in range(4):
        # Test the raw measured carrier amplitude so the response does not use
        # a phase direction estimated from the same concentration labels.
        x=LEVELS; y=np.array([np.mean([abs(r["z"][j]) for r in groups[g]]) for g in GROUPS])
        for kind in ["Pearson","Spearman"]:
            xx=rankdata(x) if kind=="Spearman" else x
            yy=rankdata(y) if kind=="Spearman" else y
            obs=np.corrcoef(xx,yy)[0,1]
            perm=np.array([np.corrcoef(xx,yy[p])[0,1] for p in permutations])
            p=float(np.mean(abs(perm)>=abs(obs)-1e-12))
            stats.append(dict(channel=f"D{j+1}",method=kind,coefficient=obs,
                              exact_two_sided_p=p,n_loading_means=6,n_technical_reads_per_loading=3,
                              response="mean_raw_carrier_amplitude"))
    for kind in ["Pearson","Spearman"]:
        which=[r for r in stats if r["method"]==kind]
        for r,p in zip(which,holm([r["exact_two_sided_p"] for r in which])):
            r["holm_p_4_channels"]=p;r["symbol"]="***" if p<.001 else "**" if p<.01 else "*" if p<.05 else "ns"
    write_csv(out/"correlation_tests.csv",stats)
    # Empirical concentration-to-complex-channel matrix from isolated 10 uM fills.
    single=np.array([np.mean([r["z"] for r in groups[f"D{i}-100C"]],axis=0)-blank for i in range(1,5)]).T
    realmat=np.real(single*np.conj(phase[:,None]))
    A=np.vstack([single.real,single.imag])/10
    superposition=single.sum(axis=1)
    recovery=[]
    for g in GROUPS:
        zz=np.mean([r["z"] for r in groups[g]],axis=0)-blank
        b=np.r_[zz.real,zz.imag]
        ls=np.linalg.lstsq(A,b,rcond=None)[0]; nonnegative=nnls(A,b)[0]
        for j in range(4):
            recovery.append(dict(group=g,assigned_uM=LEVELS[GROUPS.index(g)],channel=f"D{j+1}",
                                 unconstrained_uM=ls[j],nonnegative_uM=nonnegative[j]))
    write_csv(out/"matrix_uniform_holdouts.csv",recovery)
    write_csv(out/"empirical_matrix.csv",[dict(demodulated_channel=f"D{i+1}",source=f"D{j+1}",I_mV=single[i,j].real,
               Q_mV=single[i,j].imag,signed_mV=realmat[i,j],
               percent_of_same_source_diagonal=100*realmat[i,j]/realmat[j,j]) for i in range(4) for j in range(4)])
    # Leave-one-technical-read-out identification: never a fresh-preparation validation.
    identification=[]
    for src in range(4):
        for k,r in enumerate(groups[f"D{src+1}-100C"]):
            foldblank=np.mean([rr["z"] for kk,rr in enumerate(groups["DDW"]) if kk!=k],axis=0)
            train=np.array([np.mean([rr["z"] for kk,rr in enumerate(groups[f"D{q+1}-100C"]) if kk!=k],axis=0)-foldblank for q in range(4)]).T
            design=np.vstack([train.real,train.imag])/10
            zz=r["z"]-foldblank; co=np.linalg.lstsq(design,np.r_[zz.real,zz.imag],rcond=None)[0]
            identification.append(dict(record_id=r["id"],source=f"D{src+1}",predicted_source=f"D{np.argmax(co)+1}",
                                 predicted_D1_uM=co[0],predicted_D2_uM=co[1],predicted_D3_uM=co[2],predicted_D4_uM=co[3]))
    write_csv(out/"single_well_repeat_holdouts.csv",identification)
    active=np.array([r[f"predicted_{r['source']}_uM"] for r in identification])
    within=[]
    for r in rs:
        halves=[]
        for start in [0,4000]:
            vv=r["v"][start:start+4000];tt=r["t"][start:start+4000]
            halves.append(2/4000*(np.cos(2*np.pi*FREQ[:,None]*tt)@(vv-vv.mean())+
                                      1j*np.sin(2*np.pi*FREQ[:,None]*tt)@(vv-vv.mean())))
        for j in range(4):
            within.append(dict(record_id=r["id"],group=r["group"],channel=f"D{j+1}",
                first_second_raw_mV=abs(halves[0][j]),second_second_raw_mV=abs(halves[1][j]),
                change_percent=100*(abs(halves[1][j])/abs(halves[0][j])-1)))
    write_csv(out/"within_acquisition_stability.csv",within)
    # Transfer: blank and 10 uM anchors only; 1 uM is untouched check.
    oldg={g:[r for r in old if r["group"]==g] for g in ["DDW","10C","100C"]}
    oldblank=np.mean([r["z"] for r in oldg["DDW"]],axis=0)
    old10=np.mean([r["z"] for r in oldg["100C"]],axis=0)-oldblank
    old1=np.mean([r["z"] for r in oldg["10C"]],axis=0)-oldblank
    new10=means[4]-blank;new1=means[1]-blank
    gain=new10/old10
    transformed=new1/gain
    transfer=[dict(channel=f"D{j+1}",complex_gain_real=gain[j].real,complex_gain_imag=gain[j].imag,
                  gain_magnitude=abs(gain[j]),blank_shift_mV=abs(blank[j]-oldblank[j]),
                  held_1uM_old_response_mV=abs(old1[j]),held_1uM_aligned_response_mV=abs(transformed[j]),
                  absolute_complex_error_mV=abs(transformed[j]-old1[j]),
                  relative_complex_error_percent=100*abs(transformed[j]-old1[j])/abs(old1[j]))
              for j in range(4)]
    write_csv(out/"session_transfer_holdout.csv",transfer)
    # Equal-level, one-channel monotonic interpolation is a candidate, not a universal released calibration.
    summary=dict(version="1.0",records=30,samples_per_record=8000,sample_rate_Hz=4000,
                 independent_preparations_per_condition=1,technical_reads=3,concentrations_uM=LEVELS,
                 phase_direction=phase,blank_mV=blank,uniform_mean_mV=ym,uniform_technical_sd_mV=ys,
                 signal_cv_percent=100*ys[1:]/abs(ym[1:]),
                 iq_max_error_V=max(r["error_V"] for r in rs),
                 adc_min=min(r["adcMin"] for r in rs),adc_max=max(r["adcMax"] for r in rs),
                 matrix_condition_number=np.linalg.cond(A),empirical_single_well_mV=single,
                 uniform10_over_sum_singles=abs(new10)/abs(superposition),
                 repeat_identification_correct=sum(r["source"]==r["predicted_source"] for r in identification),
                 repeat_identification_total=12,session_transfer=transfer,correlations=stats,
                 single_well_active_recovery_uM=[active.min(),active.max()],
                 single_well_active_rmse_uM=np.sqrt(np.mean((active-10)**2)),
                 within_record_max_raw_change_percent=max(abs(r["change_percent"]) for r in within),
                 model_comparison=modelrows,
                 interpretation="Training fits, technical repeat checks and fresh-condition checks are separate. No preparation-level pairwise significance tests are identifiable from one preparation per concentration.")
    (out/"analysis_summary.json").write_text(json.dumps(clean(summary),indent=2,ensure_ascii=False),encoding="utf-8")
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":10,"axes.spines.top":False,
                         "axes.spines.right":False,"axes.titleweight":"bold","svg.fonttype":"none"})
    def save(fig,name):
        svg_path=figs/(name+".svg")
        fig.savefig(svg_path,bbox_inches="tight",metadata={"Date":None})
        # The web viewer may not have matplotlib's bundled DejaVu font.
        svg_path.write_text(svg_path.read_text("utf-8").replace(
            "font-family: 'DejaVu Sans'", "font-family: 'DejaVu Sans', Arial, sans-serif"),"utf-8")
        fig.savefig(a.preview_dir/(name+".png"),dpi=145,bbox_inches="tight")
        plt.close(fig)
    # DLIA demonstration uses a representative first 10-uM acquisition selected by rule.
    r=groups["100C"][0];v=r["v"];t=r["t"]
    fig,ax=plt.subplots(2,2,figsize=(12,8),layout="constrained")
    ax[0,0].plot(t[t<=.15],v[t<=.15],lw=1,color="#255e75")
    ax[0,0].set(xlabel="Time (s)",ylabel="ADC voltage (mV)",title="A  Measured composite waveform")
    spec=2/len(v)*abs(np.fft.rfft(v-v.mean()));ff=np.fft.rfftfreq(len(v),1/4000)
    ax[0,1].plot(ff,spec,color="#75929d",lw=.9);ax[0,1].set(xlim=(25,130),xlabel="Modulation frequency (Hz)",ylabel="Peak amplitude (mV)",title="B  Four resolved frequency components")
    for j,f in enumerate(FREQ):
        y=spec[np.argmin(abs(ff-f))];ax[0,1].plot(f,y,"o",color=COLORS[j])
        ax[0,1].annotate(f"D{j+1}\n{f} Hz",(f,y),xytext=(0,8),textcoords="offset points",ha="center",color=COLORS[j],fontsize=9)
    ax[0,1].margins(y=.3)
    ax[0,1].set_ylim(bottom=0)
    for j,f in enumerate(FREQ):
        ticks=np.arange(400,8001,100);tr=t
        running=2/ticks*(np.cumsum((v-v.mean())*np.cos(2*np.pi*f*tr))[ticks-1]+1j*np.cumsum((v-v.mean())*np.sin(2*np.pi*f*tr))[ticks-1])
        ax[1,0].plot(ticks/4000,abs(running),color=COLORS[j],label=f"D{j+1}")
    ax[1,0].set(xlabel="Integration window (s)",ylabel="Raw demodulated amplitude (mV)",title="C  Digital lock-in extraction");ax[1,0].legend(ncol=4,fontsize=8)
    xx=np.arange(4);ax[1,1].bar(xx-.18,abs(r["z"]),.36,label="Before blank subtraction",color="#a1bac4")
    ax[1,1].bar(xx+.18,r["y"],.36,color=COLORS,label="Same-session blank + phase projection")
    ax[1,1].set(xticks=xx,xticklabels=["D1","D2","D3","D4"],ylabel="Response (mV)",title="D  Extract, then remove the water baseline")
    ax[1,1].legend(fontsize=8)
    fig.suptitle("From a shared photodiode waveform to four DLIA outputs\nRaw-waveform reconstruction verified across all 30 acquisitions",fontsize=14)
    save(fig,"expanded-dlia")
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout="constrained")
    # Four curves overlaid; raw repeats retained and error bars technical SD.
    grid=np.linspace(0,20,500)
    displayed_models=["Power","Exponential","Linear","Exponential"]
    for j in range(4):
        axes[0,0].errorbar(LEVELS,ym[:,j],yerr=ys[:,j],fmt="o",color=COLORS[j],capsize=3,label=f"D{j+1}")
        axes[0,0].plot(grid,funcs[j,displayed_models[j]](grid),color=COLORS[j],lw=1.3)
    axes[0,0].set(xlabel="Sodium fluorescein (µM)",ylabel="Signed response (mV)",title="A  Four channels on one concentration axis")
    axes[0,0].legend(ncol=4,fontsize=8)
    for j in range(4):
        for i,g in enumerate(GROUPS[:5]):
            axes[0,1].plot(np.full(3,LEVELS[i])+(j-1.5)*.06,[r["y"][j] for r in groups[g]],".",color=COLORS[j])
        axes[0,1].plot(LEVELS[:5],ym[:5,j],color=COLORS[j],lw=1)
    axes[0,1].set(xlabel="Sodium fluorescein (µM)",ylabel="Signed response (mV)",title="B  Low / middle range: every technical read")
    for j in range(4):
        yy=[next(r for r in modelrows if r["channel"]==f"D{j+1}" and r["model"]==n)["level_holdout_rmse_mV"] for n in models]
        axes[1,0].plot(range(6),yy,"o-",color=COLORS[j],label=f"D{j+1}")
    axes[1,0].set(xticks=range(6),xticklabels=["Linear","Quad.","Cubic","Exp.","Power","PCHIP"],ylabel="Held-concentration RMSE (mV)",title="C  Model comparison on omitted concentration levels")
    axes[1,0].tick_params(axis="x",labelsize=9)
    axes[1,1].axis("off")
    txt=["D1–D4: 41 / 67 / 89 / 113 Hz","1 preparation × 3 technical reads per level","Lines: D1 power; D2/D4 exponential; D3 linear","Error bars: technical SD", "Concentration association (six loading means):"]
    for j in range(4):
        st=next(s for s in stats if s["channel"]==f"D{j+1}" and s["method"]=="Spearman")
        txt.append(f"D{j+1}   Spearman ρ = {st['coefficient']:.3f}   {st['symbol']}   adjusted p = {st['holm_p_4_channels']:.4f}")
    txt+=["","* p < 0.05; ** p < 0.01; ns: p ≥ 0.05","Exact permutation of raw-amplitude group means; Holm × 4.","Trend significance does not establish concentration accuracy."]
    axes[1,1].text(0,1,"\n".join(txt),va="top",fontsize=10,linespacing=1.7)
    fig.suptitle("Expanded calibration: curvature, repeatability and concentration-level checks",fontsize=14)
    save(fig,"expanded-calibration")
    fig,axes=plt.subplots(2,2,figsize=(12,9),layout="constrained");ax=axes.ravel()
    pct=100*realmat/np.diag(realmat)[None,:]
    im=ax[0].imshow(pct,norm=TwoSlopeNorm(vmin=min(-10,float(pct.min())),vcenter=0,vmax=max(100,float(pct.max()))),cmap="RdBu")
    for i in range(4):
        for j in range(4):ax[0].text(j,i,f"{pct[i,j]:.1f}",ha="center",va="center",color="white" if pct[i,j]>170 or pct[i,j]<-5 else "#182f42")
    ax[0].set(xticks=range(4),yticks=range(4),xticklabels=[f"D{i}" for i in range(1,5)],yticklabels=[f"D{i}" for i in range(1,5)],xlabel="Well containing 10 µM",ylabel="Demodulated channel",title="A  Measured cross-response (%)")
    fig.colorbar(im,ax=ax[0],shrink=.75,label="% of the filled well's own channel")
    ax[1].bar(xx-.18,abs(superposition),.36,color="#a1bac4",label="Sum of isolated-well responses")
    ax[1].bar(xx+.18,abs(new10),.36,color=COLORS,label="Measured: all four wells at 10 µM")
    ax[1].set(xticks=xx,xticklabels=["D1","D2","D3","D4"],ylabel="Blank-corrected magnitude (mV)",title="B  Independent layout check");ax[1].legend(fontsize=7)
    for j in range(4):
        yy=[r["unconstrained_uM"] for r in recovery if r["group"]=="100C" and r["channel"]==f"D{j+1}"][0]
        ax[2].bar(j,yy,color=COLORS[j]);ax[2].text(j,yy,f"{yy:.1f}",ha="center",va="bottom" if yy>=0 else "top")
    ax[2].axhline(10,color="#333",ls="--",label="Known 10 µM");ax[2].axhline(0,color="#aaa",lw=.7)
    ax[2].set(xticks=xx,xticklabels=["D1","D2","D3","D4"],ylabel="Matrix-inferred concentration (µM)",title="C  Test the inverse before adopting it");ax[2].legend(fontsize=8)
    for src in range(4):
        rr=[r for r in identification if r["source"]==f"D{src+1}"]
        vals=[r[f"predicted_D{src+1}_uM"] for r in rr]
        ax[3].scatter(np.full(3,src)+np.array([-.07,0,.07]),vals,color=COLORS[src],s=38)
    ax[3].axhline(10,color="#333",ls="--");ax[3].set(xticks=xx,xticklabels=["D1","D2","D3","D4"],ylim=(8.7,11.3),ylabel="Held-read active-well estimate (µM)",title="D  Single-well repeat-read recovery")
    ax[3].text(.03,.96,f"12/12 held reads assigned to the correct well\nRMSE {np.sqrt(np.mean((active-10)**2)):.2f} µM · same-preparation technical holdout",transform=ax[3].transAxes,va="top",fontsize=9)
    fig.suptitle("Single-well fingerprints support repeat-read recovery; check each new layout",fontsize=14)
    save(fig,"expanded-cross-response")
    if a.simulation:
        sim=np.loadtxt(a.simulation,delimiter=",",skiprows=1)
        order=[2,3,0,1];sim=sim[np.ix_(order,order)]
        # Row-normalized fractions cancel row calibration; identical normalization on both.
        empirical=realmat/realmat.sum(axis=1,keepdims=True)*100
        sim=sim/sim.sum(axis=1,keepdims=True)*100
        fig,ax=plt.subplots(1,2,figsize=(10,5),layout="constrained")
        for axis,m,title in zip(ax,[sim,empirical],["A  Liquid-volume optical simulation","B  Measured single-well responses"]):
            im=axis.imshow(m,norm=TwoSlopeNorm(vmin=-10,vcenter=0,vmax=100),cmap="RdBu")
            for i in range(4):
                for j in range(4):axis.text(j,i,f"{m[i,j]:.1f}%",ha="center",va="center",color="white" if m[i,j]>55 else "#182f42")
            axis.set(xticks=range(4),yticks=range(4),xticklabels=["D1","D2","D3","D4"],yticklabels=["D1","D2","D3","D4"],xlabel="Fluorescent source well",ylabel="LED / demodulated channel",title=title)
        fig.colorbar(im,ax=ax,shrink=.8,label="Row-normalized response (%)")
        fig.suptitle("Compare cross-response patterns using the same row normalization\n100 µL homogeneous liquid: optical simulation and single-well measurements",fontsize=12)
        save(fig,"expanded-simulation-comparison")
        write_csv(out/"simulation_comparison.csv",[dict(channel=f"D{i+1}",source=f"D{j+1}",simulation_row_percent=sim[i,j],measured_row_percent=empirical[i,j]) for i in range(4) for j in range(4)])
    fig,ax=plt.subplots(1,3,figsize=(15,4.5),layout="constrained")
    oldsaved=rs[0]["saved_blank"]
    ax[0].bar(xx-.18,abs(oldsaved),.36,label="Previously saved blank",color="#a1bac4")
    ax[0].bar(xx+.18,abs(blank),.36,label="Current water blank",color=COLORS)
    ax[0].set(xticks=xx,xticklabels=["D1","D2","D3","D4"],ylabel="Raw amplitude (mV)",title="A  Re-zero each optical configuration");ax[0].legend(fontsize=8)
    ax[1].bar(xx-.18,abs(old1),.36,color="#a1bac4",label="Previous session: measured 1 µM")
    ax[1].bar(xx+.18,abs(transformed),.36,color=COLORS,label="Current 1 µM, after 0 + 10 µM transfer")
    ax[1].set(xticks=xx,xticklabels=["D1","D2","D3","D4"],ylabel="Response on previous-session scale (mV)",title="B  An unused concentration checks the transfer");ax[1].legend(fontsize=7)
    for g,style in [("25C","o-"),("50C","s--")]:
        rr=groups[g];ax[2].plot([1,2,3],[r["y"][2] for r in rr],style,label=f"{LEVELS[GROUPS.index(g)]:g} µM · D3",color="#9162a0" if g=="25C" else "#5a8a65")
    ax[2].set(xticks=[1,2,3],xlabel="Technical read",ylabel="Same-session signed response (mV)",title="C  Keep between-read changes visible");ax[2].legend(fontsize=8)
    fig.suptitle("Session alignment and stability: anchors must pass an unused-standard check",fontsize=14)
    save(fig,"expanded-session-transfer")
    print(json.dumps(clean({k:summary[k] for k in ["iq_max_error_V","matrix_condition_number","uniform10_over_sum_singles","repeat_identification_correct","session_transfer","correlations","model_comparison"]}),indent=2))

if __name__=="__main__": main()
