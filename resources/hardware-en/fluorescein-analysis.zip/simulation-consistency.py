"""Replot saved optical matrices; no transport parameters or values are refitted.

This comparison deliberately preserves both pre-existing optical scenarios.
Red denotes positive values, blue negative, and white zero.
"""
from pathlib import Path
import argparse
import csv
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, LogNorm, LinearSegmentedColormap

P = Path(__file__).resolve().parent
STUDY = P.parent
OPTICS = STUDY.parent.parent / "02_simulation" / "optics"
ORDER = [2, 3, 0, 1]  # Archive NE,NW,SW,SE -> displayed D1,D2,D3,D4.
LABELS = ["D1", "D2", "D3", "D4"]
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.titlesize": 12,
    "axes.labelsize": 11,
    "svg.fonttype": "none",
    "svg.hashsalt": "aerosense-simulation-consistency-v1",
    "axes.spines.top": False,
    "axes.spines.right": False,
})


def save(fig, stem, out):
    for ext in ("svg", "png"):
        fig.savefig(out / f"{stem}.{ext}", dpi=180, bbox_inches="tight",
                    metadata={"Creator": "AeroSense saved-data reproduction"})
    # Browser-safe fallback, numerically identical to PNG.
    from PIL import Image
    with Image.open(out / f"{stem}.png") as im:
        im.convert("RGB").save(out / f"{stem}.webp", lossless=True)
    svg = out / f"{stem}.svg"
    text = svg.read_text(encoding="utf-8")
    text = text.replace("'DejaVu Sans'", "'DejaVu Sans', Arial, sans-serif")
    svg.write_text(text, encoding="utf-8")
    plt.close(fig)


def heatmap(ax, values, title, norm, fmt=".1f", suffix=""):
    image = ax.imshow(values, cmap="RdBu_r", norm=norm)
    for row in range(values.shape[0]):
        for column in range(values.shape[1]):
            value = values[row, column]
            color = "white" if abs(norm(value) - 0.5) > 0.28 else "#20262e"
            ax.text(column, row, f"{value:{fmt}}{suffix}",
                    ha="center", va="center", color=color, fontsize=11)
    ax.set(xticks=range(4), yticks=range(4), xticklabels=LABELS,
           yticklabels=LABELS, xlabel="Fluorescent well",
           ylabel="LED / readout channel", title=title)
    ax.tick_params(length=0, pad=7)
    ax.spines[["top", "right", "bottom", "left"]].set_visible(False)
    return image


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--empirical-matrix", type=Path,
                        default=STUDY / "derived" / "empirical_matrix.csv")
    parser.add_argument("--output", type=Path, default=P)
    args = parser.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    cell_native = np.loadtxt(OPTICS / "results" / "LED_by_well_nW.csv",
                             delimiter=",", skiprows=1)
    liquid_native = np.loadtxt(
        OPTICS / "results" / "volume_standard_LED_by_well_nW.csv",
        delimiter=",", skiprows=1)
    cell = cell_native[np.ix_(ORDER, ORDER)]
    liquid = liquid_native[np.ix_(ORDER, ORDER)]
    measured_complex = np.zeros((4, 4), dtype=complex)
    with args.empirical_matrix.open(newline="", encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            measured_complex[int(row["demodulated_channel"][1:]) - 1,
                             int(row["source"][1:]) - 1] = (
                float(row["I_mV"]) + 1j * float(row["Q_mV"]))
    # Same reference as the revised calibration, learned only from single-well
    # controls rather than the uniform-standard concentration labels.
    phase = np.diag(measured_complex) / abs(np.diag(measured_complex))
    measured = np.real(measured_complex * np.conj(phase[:, None]))
    matrices = [m / m.sum(axis=1, keepdims=True) * 100
                for m in (cell, liquid, measured)]
    stored_fraction = np.loadtxt(
        OPTICS / "results" / "volume_standard_LED_by_well_fraction.csv",
        delimiter=",", skiprows=1)[np.ix_(ORDER, ORDER)]
    assert np.allclose(matrices[1], 100 * stored_fraction, atol=1e-12)
    assert all(np.allclose(matrix.sum(axis=1), 100) for matrix in matrices)
    norm = TwoSlopeNorm(vmin=-100, vcenter=0, vmax=100)
    fig, axes = plt.subplots(1, 3, figsize=(13.1, 4.15), layout="constrained")
    for axis, matrix, title in zip(
            axes, matrices,
            ["A  Floor-layer model", "B  Liquid-volume model",
             "C  Single-well measurements"]):
        image = heatmap(axis, matrix, title, norm)
    fig.colorbar(image, ax=axes, shrink=.78, ticks=[-100, -50, 0, 50, 100],
                 label="Row-normalized response (%)")
    save(fig, "simulation-comparison-consistent", out)
    with (out / "simulation-comparison-consistent.csv").open(
            "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=[
            "channel", "source", "floor_layer_nW", "volume_nW",
            "measured_signed_mV", "floor_layer_row_percent",
            "volume_row_percent", "measured_row_percent"])
        writer.writeheader()
        for i in range(4):
            for j in range(4):
                writer.writerow(dict(
                    channel=LABELS[i], source=LABELS[j],
                    floor_layer_nW=cell[i, j], volume_nW=liquid[i, j],
                    measured_signed_mV=measured[i, j],
                    floor_layer_row_percent=matrices[0][i, j],
                    volume_row_percent=matrices[1][i, j],
                    measured_row_percent=matrices[2][i, j]))
    # Identical earlier power matrix: only the palette/layout change.
    fig, axis = plt.subplots(figsize=(6.4, 5.4), layout="constrained")
    image = heatmap(axis, cell, "", TwoSlopeNorm(
        vmin=-float(cell.max()), vcenter=0, vmax=float(cell.max())), ".3f")
    fig.colorbar(image, ax=axis, shrink=.8, label="Collected green power (nW)")
    save(fig, "simulation-floor-transfer-red", out)
    fig, axis = plt.subplots(figsize=(6.4, 5.4), layout="constrained")
    image = heatmap(axis, matrices[1], "", norm)
    fig.colorbar(image, ax=axis, shrink=.8,
                 label="Row-normalized response (%)")
    save(fig, "simulation-volume-transfer-red", out)
    # Earlier irradiance and collection maps, unchanged spatial source arrays.
    fields = np.load(OPTICS / "code" / "data" / "spatial_maps.npz")
    fig, axes = plt.subplots(2, 4, figsize=(12, 6.15), layout="constrained")
    for row, key, unit in [
            (0, "floor_irradiance_uW_mm2", "Irradiance (µW/mm²)"),
            (1, "eta", "Collection (%)")]:
        data = fields[key] * (100 if row == 1 else 1)
        scale = float(data.max())
        color_norm = TwoSlopeNorm(vmin=-scale, vcenter=0, vmax=scale)
        for column, index in enumerate(ORDER):
            axis = axes[row, column]
            image = axis.imshow(data[index].T, origin="lower", cmap="RdBu_r",
                                norm=color_norm,
                                extent=[1.3, 5.3, 1.25, 4.05], aspect="auto")
            axis.set(title=LABELS[column], xlabel="Local x (mm)",
                     ylabel="Local y (mm)")
        fig.colorbar(image, ax=axes[row], label=unit, shrink=.85,
                     ticks=np.linspace(0, scale, 4))
    save(fig, "simulation-floor-maps-red", out)
    # Photon-budget cells are strictly positive, with the same legacy log scale.
    budget = []
    with (OPTICS / "results" / "conditional_photon_budget.csv").open(
            newline="", encoding="utf-8-sig") as stream:
        budget = list(csv.DictReader(stream))
    powers = [.05, .1, .5, 1., 2.]
    changes = [.01, .05, .1, .5]
    values = np.array([[
        float(next(row for row in budget
                   if float(row["LED_on_mW"]) == power
                   and float(row["QY"]) == .6
                   and float(row["deltaF_over_F"]) == change)[
                       "max_lockin_amplitude_RMS_noise_pW_for_SNR5"])
        for power in powers] for change in changes])
    reds = LinearSegmentedColormap.from_list(
        "white_to_red", ["#fffafa", "#f6a28b", "#b2182b", "#67001f"])
    fig, axis = plt.subplots(figsize=(7.5, 4.8), layout="constrained")
    image = axis.imshow(values, cmap=reds, norm=LogNorm(vmin=.01, vmax=100))
    for i in range(4):
        for j in range(5):
            axis.text(j, i, f"{values[i, j]:.2f}", ha="center", va="center",
                      color="white" if values[i, j] > 3 else "#20262e")
    axis.set(xticks=range(5), xticklabels=powers,
             yticks=range(4), yticklabels=[1, 5, 10, 50],
             xlabel="LED-on power (mW)", ylabel="ΔF/F (%)")
    fig.colorbar(image, ax=axis, shrink=.85, label="Noise threshold (pW RMS)")
    save(fig, "simulation-photon-budget-red", out)
    report = {
        "registration": {"D1": "SW", "D2": "SE", "D3": "NE", "D4": "NW"},
        "registration_status": "CAD/frequency mapping; physical sample-well wiring not independently verified",
        "row_definition": "LED/demodulated channel",
        "column_definition": "fluorescent source well",
        "normalization": "100 * entry / signed row sum, identical for all three matrices",
        "floor_layer": {
            "thickness_um": 20, "absorption_per_mm": .5, "fill_uL": 100,
            "diagonal_percent": np.diag(matrices[0]).tolist(),
            "data": "../../../02_simulation/optics/results/LED_by_well_nW.csv"},
        "liquid_volume": {
            "thickness_um": None, "absorption_per_mm": .001, "fill_uL": 100,
            "diagonal_percent": np.diag(matrices[1]).tolist(),
            "data": "../../../02_simulation/optics/results/volume_standard_LED_by_well_nW.csv"},
        "measurement": {
            "data": "../derived/empirical_matrix.csv" if
                    args.empirical_matrix == STUDY / "derived" / "empirical_matrix.csv"
                    else str(args.empirical_matrix),
            "diagonal_percent": np.diag(matrices[2]).tolist(),
            "phase_reference": "Each channel's own blank-subtracted single-well 10 µM control",
            "phase_angle_degrees": np.angle(phase, deg=True).tolist(),
            "note": "Blank-subtracted signed channel response includes optical, electronics, and state-dependent contributions; not isolated green photon power."},
        "models_max_absolute_difference_percentage_points":
            float(np.max(np.abs(matrices[0] - matrices[1]))),
        "measured_vs_floor_layer_rmse_percentage_points":
            float(np.sqrt(np.mean((matrices[2] - matrices[0])**2))),
        "measured_vs_volume_rmse_percentage_points":
            float(np.sqrt(np.mean((matrices[2] - matrices[1])**2))),
        "invariant_checks": {
            "row_sums": [matrix.sum(axis=1).tolist() for matrix in matrices],
            "floor_source_unchanged": True,
            "volume_source_unchanged": True}}
    (out / "simulation-consistency-audit.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
