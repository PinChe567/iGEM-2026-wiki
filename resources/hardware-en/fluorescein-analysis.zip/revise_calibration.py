"""Reassess the shared curve family, source unmixing and 2.5-uM repeat loading.

Raw data are never edited. Three consecutive reads are technical replicates.
The additional 2.5-uM loading is archived separately because it predates the
other acquisitions and lacks a matching contemporaneous water blank.
"""
from pathlib import Path
import argparse
import itertools
import json
import shutil
import warnings

import numpy as np
from scipy.stats import rankdata
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
import analyze_fluorescein as original

COLORS = original.COLORS
NAMES = ["D1", "D2", "D3", "D4"]
FAMILIES = ["Linear", "Quadratic", "Exponential", "Power"]
PRIMARY_INDEX = [0, 1, 3, 4, 5]


def fit(x, y, family):
    """Same family, channel-specific coefficients; no forced positive inversion."""
    direction = 1.0 if np.cov(x, y)[0, 1] >= 0 else -1.0
    f0, parameters = original.fit_model(np.asarray(x), direction * np.asarray(y), family)
    f = lambda c: direction * f0(c)
    differences = np.diff(f(np.linspace(0, 20, 2001)))
    monotonic = bool(np.all(differences > 0) or np.all(differences < 0))
    return f, parameters, direction, monotonic


def inverse(f, y):
    return original.inverse(f, float(y), upper=20)


def error_metrics(errors):
    errors = np.asarray(errors, float)
    valid = np.isfinite(errors)
    return {
        "n_valid": int(valid.sum()),
        "n_invalid": int((~valid).sum()),
        "rmse_uM": float(np.sqrt(np.mean(errors[valid] ** 2))) if valid.any() else np.nan,
        "mae_uM": float(np.mean(np.abs(errors[valid]))) if valid.any() else np.nan,
        "bias_uM": float(np.mean(errors[valid])) if valid.any() else np.nan,
        "max_absolute_error_uM": float(np.max(np.abs(errors[valid]))) if valid.any() else np.nan,
    }


def evaluate_family(x, y, family, variant, preprocessing):
    rows = []
    for held in range(1, len(x) - 1):
        train = np.arange(len(x)) != held
        for j, channel in enumerate(NAMES):
            f, _, _, monotonic = fit(x[train], y[train, j], family)
            pred, nroots = inverse(f, y[held, j])
            rows.append({
                "dataset": variant, "preprocessing": preprocessing,
                "family": family, "channel": channel,
                "held_concentration_uM": float(x[held]),
                "held_response": float(y[held, j]),
                "predicted_concentration_uM": pred,
                "residual_uM": pred - x[held],
                "inverse_roots_in_0_20": nroots,
                "fold_monotonic": monotonic,
            })
    full_monotonic = all(fit(x, y[:, j], family)[3] for j in range(4))
    metrics = error_metrics([r["residual_uM"] for r in rows])
    return rows, dict(dataset=variant, preprocessing=preprocessing, family=family,
                      full_fits_monotonic=full_monotonic,
                      all_fold_fits_monotonic=all(r["fold_monotonic"] for r in rows),
                      **metrics)


def exact_trend(x, raw_means, dataset):
    """Permute concentration labels jointly, preserving four-channel dependence."""
    permutations = np.asarray(list(itertools.permutations(range(len(x)))))
    rows = []
    for kind in ["Spearman", "Pearson"]:
        xx = rankdata(x) if kind == "Spearman" else x.copy()
        yy = np.apply_along_axis(rankdata, 0, raw_means) if kind == "Spearman" else raw_means
        xx = (xx - xx.mean()) / np.sqrt(np.sum((xx - xx.mean()) ** 2))
        yy = (yy - yy.mean(axis=0)) / np.sqrt(np.sum((yy - yy.mean(axis=0)) ** 2, axis=0))
        observed = xx @ yy
        permuted = xx[permutations] @ yy
        p_values = np.mean(np.abs(permuted) >= np.abs(observed)[None, :] - 1e-12, axis=0)
        adjusted = original.holm(p_values)
        for j in range(4):
            rows.append(dict(dataset=dataset, test=kind, channel=NAMES[j],
                             coefficient=float(observed[j]), exact_two_sided_p=float(p_values[j]),
                             holm_p_4_channels=float(adjusted[j]),
                             symbol="*" if adjusted[j] < .05 else "ns",
                             n_loading_means=len(x)))
        global_observed = observed.mean()
        global_permuted = permuted.mean(axis=1)
        global_p = float(np.mean(abs(global_permuted) >= abs(global_observed) - 1e-12))
        rows.append(dict(dataset=dataset, test=kind, channel="Joint D1-D4",
                         coefficient=float(global_observed), exact_two_sided_p=global_p,
                         holm_p_4_channels=np.nan, symbol="*" if global_p < .05 else "ns",
                         n_loading_means=len(x)))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, required=True)
    parser.add_argument("--new-25-root", type=Path)
    parser.add_argument("--preview-dir", type=Path, required=True)
    args = parser.parse_args()
    newroot = args.new_25_root or args.data_root / "raw" / "new_25C"
    out = args.data_root / "revision"
    figures = out / "figures"
    for p in [out, figures, args.preview_dir]:
        p.mkdir(exist_ok=True, parents=True)
    records = original.load(args.data_root / "raw")
    additional = original.load(newroot)
    assert len(records) == 30 and len(additional) == 3
    group_names = original.GROUPS + [f"D{i}-100C" for i in range(1, 5)]
    groups = {g: [r for r in records if r["group"] == g] for g in group_names}
    assert all(len(group) == 3 for group in groups.values())
    z = np.array([[r["z"] for r in groups[g]] for g in original.GROUPS])
    blank = z[0].mean(axis=0)
    source = np.array([[r["z"] for r in groups[f"D{i}-100C"]] for i in range(1, 5)])
    matrix = (source.mean(axis=1) - blank).T
    # The phase is determined by isolated sources, independently of uniform labels.
    phase = np.diag(matrix) / abs(np.diag(matrix))
    design = np.vstack([matrix.real, matrix.imag])
    projected = np.real((z - blank) * np.conj(phase))
    additional_z = np.array([r["z"] for r in additional])
    additional_projected = np.real((additional_z - blank) * np.conj(phase))
    original_means = z.mean(axis=1)
    raw_means = np.mean(abs(z), axis=1)
    levels = original.LEVELS.copy()
    datasets = {
        "all_original": (levels, original_means),
        "additional_25_substitution": (levels, original_means.copy()),
        "primary_excluding_25": (levels[PRIMARY_INDEX], original_means[PRIMARY_INDEX]),
    }
    datasets["additional_25_substitution"][1][2] = additional_z.mean(axis=0)
    summary_rows, cv_rows = [], []
    for variant, (x, means) in datasets.items():
        centered = means - blank
        responses = {
            "same_session_blank": np.real(centered * np.conj(phase)),
            "single_source_matrix": 10 * np.linalg.lstsq(
                design, np.hstack([centered.real, centered.imag]).T, rcond=None
            )[0].T,
        }
        for method, y in responses.items():
            for family in FAMILIES:
                rows, summary = evaluate_family(x, y, family, variant, method)
                cv_rows.extend(rows)
                summary_rows.append(summary)
    original.write_csv(out / "shared_family_comparison.csv", summary_rows)
    original.write_csv(out / "concentration_holdouts_all_variants.csv", cv_rows)
    eligible = [
        r for r in summary_rows
        if r["dataset"] == "primary_excluding_25" and r["preprocessing"] == "same_session_blank"
        and r["n_invalid"] == 0 and r["full_fits_monotonic"] and r["all_fold_fits_monotonic"]
    ]
    selected = min(eligible, key=lambda r: r["rmse_uM"])
    family = selected["family"]
    x = levels[PRIMARY_INDEX]
    y = projected.mean(axis=1)[PRIMARY_INDEX]
    sd = projected.std(axis=1, ddof=1)[PRIMARY_INDEX]
    coefficient_rows, training_rows = [], []
    functions = []
    for j, channel in enumerate(NAMES):
        f, parameters, direction, monotonic = fit(x, y[:, j], family)
        functions.append(f)
        coefficient_rows.append(dict(
            channel=channel, family=family, a_mV=float(parameters[0] * direction),
            b_mV=float(parameters[1] * direction), k=float(parameters[2]) if len(parameters) > 2 else np.nan,
            scale_uM=20, valid_min_uM=0, valid_max_uM=20,
            phase_real=float(phase[j].real), phase_imag=float(phase[j].imag),
            blank_I_mV=float(blank[j].real), blank_Q_mV=float(blank[j].imag),
            monotonic=monotonic, fit_parameters=json.dumps(parameters.tolist()),
        ))
        for c, response, technical_sd in zip(x, y[:, j], sd[:, j]):
            predicted, nroots = inverse(f, response)
            training_rows.append(dict(channel=channel, assigned_uM=float(c),
                                      response_mean_mV=float(response),
                                      technical_sd_mV=float(technical_sd), fitted_mV=float(f(c)),
                                      inverse_training_uM=predicted, inverse_roots=nroots))
    original.write_csv(out / "calibration_coefficients.csv", coefficient_rows)
    original.write_csv(out / "calibration_training.csv", training_rows)
    primary_cv = [r for r in cv_rows if r["dataset"] == "primary_excluding_25"
                  and r["preprocessing"] == "same_session_blank" and r["family"] == family]
    original.write_csv(out / "primary_concentration_holdouts.csv", primary_cv)
    # Outer held levels never participate in the fitting of a residual correction.
    # Only two inner held levels remain in each outer fold: this deliberately
    # exposes how unstable a fitted affine correction can be with this design.
    residual_rows = []
    for held in range(1, len(x) - 1):
        keep = np.arange(len(x)) != held
        tx, ty = x[keep], y[keep]
        for j, channel in enumerate(NAMES):
            outer_f, _, _, _ = fit(tx, ty[:, j], family)
            pred, _ = inverse(outer_f, y[held, j])
            inner_pred, inner_true = [], []
            for inner in range(1, len(tx) - 1):
                ik = np.arange(len(tx)) != inner
                inner_f, _, _, _ = fit(tx[ik], ty[ik, j], family)
                q, nr = inverse(inner_f, ty[inner, j])
                if nr == 1 and np.isfinite(q):
                    inner_pred.append(q)
                    inner_true.append(tx[inner])
            inner_pred = np.array(inner_pred)
            residual = inner_pred - np.array(inner_true)
            offset = float(residual.mean()) if len(residual) else np.nan
            affine = np.full(2, np.nan)
            if len(residual) >= 2 and np.ptp(inner_pred) > 1e-8:
                affine = np.linalg.lstsq(np.c_[np.ones(len(residual)), inner_pred], residual, rcond=None)[0]
            for correction in ["None", "Constant", "Linear"]:
                adjusted = pred
                a, b = 0., 0.
                if correction == "Constant":
                    adjusted = pred - offset
                    a = offset
                elif correction == "Linear":
                    adjusted = pred - (affine[0] + affine[1] * pred)
                    a, b = affine
                residual_rows.append(dict(
                    channel=channel, held_concentration_uM=float(x[held]), correction=correction,
                    uncorrected_uM=pred, corrected_uM=adjusted,
                    error_uM=adjusted - x[held],
                    learned_residual_offset_uM=float(a), learned_residual_slope=float(b),
                    n_inner_concentration_holdouts=len(residual),
                    in_calibrated_range=bool(np.isfinite(adjusted) and 0 <= adjusted <= 20),
                ))
    original.write_csv(out / "nested_residual_correction_holdouts.csv", residual_rows)
    residual_summary = []
    for channel in ["All"] + NAMES:
        for correction in ["None", "Constant", "Linear"]:
            rows = [r for r in residual_rows if r["correction"] == correction
                    and (channel == "All" or r["channel"] == channel)]
            residual_summary.append(dict(
                channel=channel, correction=correction,
                out_of_range=sum(not r["in_calibrated_range"] for r in rows),
                **error_metrics([r["error_uM"] for r in rows]),
            ))
    original.write_csv(out / "nested_residual_correction_summary.csv", residual_summary)
    # A correction derived from the complete set of out-of-fold predictions is
    # provided as an exploratory diagnostic, never scored on those same points.
    residual_coefficients = []
    for j, channel in enumerate(NAMES):
        rows = [r for r in primary_cv if r["channel"] == channel]
        predictions = np.array([r["predicted_concentration_uM"] for r in rows])
        residuals = np.array([r["residual_uM"] for r in rows])
        affine = np.linalg.lstsq(np.c_[np.ones(len(rows)), predictions], residuals, rcond=None)[0]
        residual_coefficients.append(dict(
            channel=channel, constant_residual_uM=float(residuals.mean()),
            linear_residual_intercept_uM=float(affine[0]), linear_residual_slope=float(affine[1]),
            n_concentration_holdouts=len(rows),
            status="diagnostic coefficients; deployment not justified by nested holdouts",
        ))
    original.write_csv(out / "exploratory_residual_coefficients.csv", residual_coefficients)
    # Ridge tuning uses source/blank technical holdouts only, never uniform data.
    lambdas = np.r_[0, np.logspace(-8, 0, 25)]
    ridge_rows = []
    for lam in lambdas:
        errors = []
        for k in range(3):
            fold_blank = np.delete(z[0], k, axis=0).mean(axis=0)
            fold_matrix = (np.delete(source, k, axis=1).mean(axis=1) - fold_blank).T
            a = np.vstack([fold_matrix.real, fold_matrix.imag])
            penalty = lam * np.linalg.norm(a, 2) ** 2
            for src in range(4):
                centered = source[src, k] - fold_blank
                b = np.r_[centered.real, centered.imag]
                estimated = 10 * np.linalg.solve(a.T @ a + penalty * np.eye(4), a.T @ b)
                truth = np.eye(4)[src] * 10
                errors.extend(estimated - truth)
        ridge_rows.append(dict(lambda_relative=float(lam),
                               technical_component_rmse_uM=float(np.sqrt(np.mean(np.array(errors) ** 2)))))
    best_ridge = min(ridge_rows, key=lambda r: r["technical_component_rmse_uM"])
    original.write_csv(out / "ridge_source_holdout_selection.csv", ridge_rows)
    matrix_uniform_rows = []
    matrix_variants = {}
    for method, lam in [("Unregularized", 0), ("Ridge", best_ridge["lambda_relative"])]:
        penalty = lam * np.linalg.norm(design, 2) ** 2
        response = original_means - blank
        recovered = 10 * np.linalg.solve(
            design.T @ design + penalty * np.eye(4),
            design.T @ np.hstack([response.real, response.imag]).T,
        ).T
        matrix_variants[method] = recovered
        for i, c in enumerate(levels):
            for j, channel in enumerate(NAMES):
                matrix_uniform_rows.append(dict(method=method, assigned_uM=float(c), channel=channel,
                                                recovered_uM=float(recovered[i, j]),
                                                residual_uM=float(recovered[i, j] - c)))
    original.write_csv(out / "matrix_uniform_recovery.csv", matrix_uniform_rows)
    statistics = exact_trend(x, raw_means[PRIMARY_INDEX], "primary_excluding_25")
    statistics += exact_trend(levels, raw_means, "all_original")
    statistics += exact_trend(
        np.r_[levels, 2.5], np.vstack([raw_means, np.mean(abs(additional_z), axis=0)]),
        "original_plus_additional_25",
    )
    original.write_csv(out / "trend_statistics.csv", statistics)
    qc_rows = []
    for label, reads, zz, projected_reads in [
        ("Original 2.5 uM", groups["25C"], z[2], projected[2]),
        ("Additional 2.5 uM", additional, additional_z, additional_projected),
    ]:
        for j, channel in enumerate(NAMES):
            amplitude = abs(zz[:, j])
            qc_rows.append(dict(
                loading=label, channel=channel,
                record_ids=";".join(r["id"] for r in reads),
                device_midpoints_s=";".join(str(r["deviceTimeMs"] / 1000) for r in reads),
                mean_raw_mV=float(amplitude.mean()), technical_sd_raw_mV=float(amplitude.std(ddof=1)),
                technical_cv_raw_percent=float(100 * amplitude.std(ddof=1) / amplitude.mean()),
                signed_blank_corrected_mV=float(projected_reads[:, j].mean()),
                technical_sd_net_mV=float(projected_reads[:, j].std(ddof=1)),
            ))
    original.write_csv(out / "additional_25_comparison.csv", qc_rows)
    selected_original = next(r for r in summary_rows if r["dataset"] == "all_original"
                             and r["preprocessing"] == "same_session_blank" and r["family"] == family)
    global_spearman = next(r for r in statistics if r["dataset"] == "primary_excluding_25"
                           and r["test"] == "Spearman" and r["channel"] == "Joint D1-D4")
    result = dict(
        revision="shared-family-2026-10-20", selected_common_family=family,
        primary_selection=selected, original_25_sensitivity=selected_original,
        phase_source="own isolated 10 uM response; independent of uniform concentration labels",
        response="fresh-session complex blank subtraction, then fixed signed phase projection",
        preprocessing_scope="Uniform-loading empirical calibration; source-matrix inversion evaluated separately and not accepted for arbitrary mixtures.",
        primary_levels_uM=x, qc_exclusion="Original 2.5 uM: abrupt D3 between-read state change. Additional 2.5 uM: earlier acquisition without matching blank; retained separately.",
        exclusion_status="Post hoc exploratory QC exclusion; full-original and additional-substitution sensitivities retained.",
        training_fit_metrics=error_metrics([r["inverse_training_uM"] - r["assigned_uM"] for r in training_rows]),
        primary_concentration_holdouts=primary_cv, coefficients=coefficient_rows,
        nested_residual_correction=residual_summary,
        correction_formula="c_adjusted = c_predicted - (a + b*c_predicted)",
        ridge_selection=best_ridge, matrix_condition_number=float(np.linalg.cond(design)),
        matrix_uniform_10uM=matrix_variants["Unregularized"][4],
        ridge_uniform_10uM=matrix_variants["Ridge"][4],
        global_trend=global_spearman,
        statistics_scope="Exploratory joint concentration-label permutation across loading means. Three technical reads are averaged; no pairwise independent-replicate significance.",
        original_25_qc=qc_rows[:4], additional_25_qc=qc_rows[4:],
        independent_preparations_per_original_concentration=1,
        technical_reads_per_loading=3,
        calibration_range_uM=[0, 20],
        heldout_internal_levels_uM=x[1:-1],
        limitations=[
            "Uniform samples do not validate independently varying unknown well concentrations.",
            "Family selection and QC decisions are exploratory; concentration holdouts are not a new blinded experimental batch.",
            "Residual-correction parameters are never evaluated on their own fitting points.",
            "Three technical reads quantify reading repeatability, not preparation uncertainty.",
            "No clipping of negative source estimates or out-of-range corrected estimates.",
        ],
    )
    (out / "revision_summary.json").write_text(
        json.dumps(original.clean(result), indent=2, ensure_ascii=False), encoding="utf-8"
    )
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "axes.titleweight": "bold", "svg.fonttype": "none"})
    def save(fig, name):
        file = figures / (name + ".svg")
        fig.savefig(file, bbox_inches="tight", metadata={"Date": None})
        file.write_text(file.read_text("utf-8").replace(
            "font-family: 'DejaVu Sans'", "font-family: 'DejaVu Sans', Arial, sans-serif"), "utf-8")
        fig.savefig(args.preview_dir / (name + ".png"), dpi=170, bbox_inches="tight")
        plt.close(fig)
    fig, ax = plt.subplots(figsize=(8.0, 5.1))
    for j in range(4):
        ax.errorbar(x, y[:, j], yerr=sd[:, j], fmt="o", color=COLORS[j], capsize=3,
                    ms=5, label=NAMES[j])
        xx = np.linspace(0, 20, 401)
        ax.plot(xx, functions[j](xx), color=COLORS[j], lw=1.7)
    ax.set(xlabel="Sodium fluorescein (µM)", ylabel="Blank-corrected response (mV)",
           xlim=(-.4, 20.8))
    ax.legend(ncol=4, frameon=False, loc="upper left")
    ax.text(.98, 1.035, "D1–D4 trend " + global_spearman["symbol"], transform=ax.transAxes,
            ha="right", va="bottom", fontsize=11, weight="bold")
    ax.grid(alpha=.16)
    fig.tight_layout()
    save(fig, "revised-calibration")
    fig, axes = plt.subplots(1, 3, figsize=(13.1, 4.0))
    for j, channel in enumerate(NAMES):
        rows = [r for r in primary_cv if r["channel"] == channel]
        actual = np.array([r["held_concentration_uM"] for r in rows])
        predicted = np.array([r["predicted_concentration_uM"] for r in rows])
        axes[0].plot(actual, predicted, "o", color=COLORS[j], label=channel, ms=6)
        axes[1].plot(actual, predicted - actual, "o-", color=COLORS[j], lw=1.1, ms=5)
    axes[0].plot([0, 12], [0, 12], "--", color="#777777", lw=1.2)
    axes[0].set(xlabel="Actual concentration (µM)", ylabel="Predicted concentration (µM)",
                xlim=(0, 12), ylim=(0, 12), title="A")
    axes[0].legend(ncol=2, frameon=False, fontsize=9)
    axes[1].axhline(0, color="#777777", lw=1, ls="--")
    axes[1].set(xlabel="Actual concentration (µM)", ylabel="Prediction residual (µM)", title="B")
    xx = np.arange(4)
    for i, (method, color) in enumerate(zip(["None", "Constant", "Linear"],
                                           ["#79919c", "#bd734c", "#7e5a91"])):
        rows = [next(r for r in residual_summary if r["channel"] == ch and r["correction"] == method)
                for ch in NAMES]
        axes[2].bar(xx + (i - 1) * .24, [r["rmse_uM"] for r in rows], .23, color=color, label=method)
    axes[2].set(xticks=xx, xticklabels=NAMES, ylabel="Nested holdout RMSE (µM)", title="C")
    axes[2].legend(frameon=False, fontsize=8)
    for ax in axes:
        ax.grid(alpha=.15)
    fig.tight_layout(w_pad=2)
    save(fig, "revised-concentration-recovery")
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 4.3))
    signed_matrix = np.real(matrix * np.conj(phase[:, None]))
    relative = 100 * signed_matrix / signed_matrix.sum(axis=1)[:, None]
    original.write_csv(out / "empirical_row_fraction.csv", [
        dict(readout_channel=NAMES[i], loaded_source=NAMES[j],
             signed_response_mV=float(signed_matrix[i,j]),
             row_fraction_percent=float(relative[i,j]))
        for i in range(4) for j in range(4)])
    # Red is positive and blue is negative. Never use abs() to hide negatives.
    matrix_limit = 100.
    norm = TwoSlopeNorm(vcenter=0, vmin=-matrix_limit, vmax=matrix_limit)
    im = axes[0].imshow(relative, cmap="RdBu_r", norm=norm)
    axes[0].set(xticks=range(4), xticklabels=NAMES, yticks=range(4), yticklabels=NAMES,
                xlabel="Loaded source", ylabel="Readout channel", title="A")
    for i in range(4):
        for j in range(4):
            axes[0].text(j, i, f"{relative[i,j]:.1f}", ha="center", va="center",
                         color="white" if abs(relative[i,j]) > matrix_limit * .65 else "#222222", fontsize=9)
    fig.colorbar(im, ax=axes[0], label="Row-normalized response (%)", shrink=.85)
    recovered = matrix_variants["Unregularized"][PRIMARY_INDEX]
    limit = float(np.ceil(np.max(abs(recovered)) / 10) * 10)
    im2 = axes[1].imshow(recovered, cmap="RdBu_r", norm=TwoSlopeNorm(vcenter=0, vmin=-limit, vmax=limit),
                         aspect="auto")
    axes[1].set(xticks=range(4), xticklabels=NAMES, yticks=range(len(x)),
                yticklabels=[f"{c:g}" for c in x], xlabel="Estimated source",
                ylabel="Actual uniform concentration (µM)", title="B")
    for i in range(len(x)):
        for j in range(4):
            value = 0. if abs(recovered[i,j]) < .05 else recovered[i,j]
            axes[1].text(j, i, f"{value:.1f}", ha="center", va="center",
                         color="white" if abs(recovered[i,j]) > limit * .65 else "#222222", fontsize=9)
    fig.colorbar(im2, ax=axes[1], label="Unmixed estimate (µM)", shrink=.85)
    fig.tight_layout(w_pad=2)
    save(fig, "revised-matrix-diagnostic")
    fig, axes = plt.subplots(1, 2, figsize=(9.7, 4.1))
    for i, (label, color, zz, yy) in enumerate([
        ("Original 2.5 µM", "#8f5790", z[2], projected[2]),
        ("Additional 2.5 µM", "#237b86", additional_z, additional_projected),
    ]):
        positions = np.arange(4) + (i - .5) * .22
        axes[0].errorbar(positions, abs(zz).mean(axis=0), abs(zz).std(axis=0, ddof=1),
                         fmt="o", capsize=4, color=color, label=label)
        axes[1].errorbar(positions, yy.mean(axis=0), yy.std(axis=0, ddof=1),
                         fmt="o", capsize=4, color=color)
    for ax in axes:
        ax.set(xticks=range(4), xticklabels=NAMES, xlabel="Readout channel")
        ax.grid(alpha=.15)
    axes[0].legend(frameon=False, fontsize=9)
    axes[0].set(ylabel="Raw carrier amplitude (mV)", title="A")
    axes[1].set(ylabel="Blank-corrected response (mV)", title="B")
    axes[1].axhline(0, ls="--", lw=1, color="#777777")
    fig.tight_layout(w_pad=2)
    save(fig, "revised-25-qc")
    shutil.copy2(Path(__file__), out / "revise_calibration.py")
    shutil.copy2(Path(original.__file__), out / "analyze_fluorescein.py")
    print(json.dumps(original.clean({
        "selected": selected, "coefficients": coefficient_rows,
        "primary_holdouts": primary_cv,
        "residual_summary": [r for r in residual_summary if r["channel"] == "All"],
        "ridge": best_ridge, "ridge_uniform10": result["ridge_uniform_10uM"],
        "global_trend": global_spearman,
    }), indent=2))


if __name__ == "__main__":
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        main()
