# Supplementary 2.5 µM acquisition audit

The original filename label 25C means 2.5 µM sodium fluorescein, 100 µL in each of D1–D4. Each series contains three consecutive technical readings of one preparation. They are not three independent preparations.

## File and acquisition provenance

The six newly supplied raw files are preserved without modification in ../../raw/new_25C/. They total 2,155,937 bytes; individual source paths, byte counts and SHA-256 digests are recorded in new25-archive-verification.json and ../../raw_manifest.csv. The original 25C series remains in ../../raw/.

The folder name new_25C indicates when the files were supplied, not acquisition chronology. The supplied series has IDs b16e0cdc-4 through -6, acquired at device midpoint times 315.837265–331.776228 seconds and exported 2026-10-20 04:36:06–04:36:18 UTC. The original series has IDs b16e0cdc-38 through -40, acquired at 2250.929683–2268.996739 seconds and exported 05:05:16–05:05:25 UTC. Both identify the same boot and device. The current water group was acquired at 2018.228265–2043.892613 seconds. No contemporaneous water reference accompanies IDs 4–6.

The selected record is records[0], cross-checked against selectedRecordId and the paired raw CSV. deviceStatus.latest describes a different most-recent record at export; it is not the selected 25C measurement. All reports retain an older saved UI blank, IDs ac338400-24 through -28. The offline audit uses the current water group rather than that older UI blank.

## Acquisition checks

All six 25C records have the same acquisition signature, device, boot, sampling rate (4000 Hz), sample count (8000), LED duty (25%) and modulation frequencies (41/67/89/113 Hz for D1–D4). All selected records are valid, with no timing faults or rail events. Raw ADC CSV arrays equal the JSON-embedded CSV arrays. Recomputed I/Q from newly supplied CSV data agree with saved I/Q within 5.813e-10 V. Raw ADC maxima for the newly supplied records are 6599, 6654 and 6602.

For each one-second half, the four integer-Hz Fourier coefficients were recomputed using the original sample-clock phase. The largest absolute half-to-half carrier-amplitude change among the newly supplied records was 0.599%. This is carrier stability, not a claim that net fluorescence uncertainty is 0.599%.

## Comparison independent of calibration fit quality

Raw carrier-amplitude CVs across the three newly supplied readings are 0.201%, 0.177%, 0.290% and 0.416% for D1–D4. The original series gives 1.404%, 5.295%, 30.273% and 1.289%. Original D3 changes from 38.019 to 68.841 to 68.490 mV, an 81.068% first-to-second-read jump. The newer supplied files therefore provide substantially more repeatable carrier readings.

However, their raw mean amplitudes are 23.198, 27.516, 25.292 and 33.052 mV, whereas the later water reference is 16.842, 22.076, 30.275 and 41.203 mV. Their D3 and D4 means fall below that water reference. Projecting the current-water-subtracted I/Q along the original uniform-series slope gives signed means 6.356, 5.437, -4.986 and -8.158 mV. Using the isolated-source diagonal phase instead gives 6.356, 5.432, -4.988 and -8.158 mV: the conclusion does not depend on choosing the uniform fit phase.

## Calibration disposition

Keep both 25C acquisitions as raw data and QC evidence. The original series has an objective between-read state change in D3, so it can be omitted from a primary candidate calibration with an explicit retrospective QC flag and retained in a sensitivity fit. The earlier acquisition is repeatable but lacks a matching water/anchor reference and has an incompatible later-water baseline; do not substitute it directly into the later calibration or invent a gain/offset to force agreement. The physical cause of the state difference is not identified by these files. The data do not establish that 2.5 µM is intrinsically below the instrument's detection limit.

new25-comparison.csv/json report raw mean/SD/CV, signed net mean/SD/CV under both phase conventions, the current water reference, and first-to-second change. new25-acquisition-audit.json records the provenance and half-trace checks for all 33 acquisitions. CV after subtraction is descriptive and can be unstable near zero; negative signals remain signed.
