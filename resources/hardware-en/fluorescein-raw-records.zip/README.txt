58 paired acquisitions: 58 original JSON reports and 58 original ADC CSV files.
The initial, expanded and additional 2.5 uM loading directories are preserved separately.
No raw values are edited. Consecutive technical reads must not be treated as independent preparations.
The SHA256 manifest checks every original payload byte.
