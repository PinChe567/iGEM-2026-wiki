Current English manuals and USD BOM, source revision 2026-10-11. Procedures and blank forms are not completed experimental evidence. Read the website limitations and original manual prerequisites before use. Companion figures referenced by Markdown are embedded in the PDFs.

The published BOM is an English text-only edition of the supplied English workbook. Three vendor labels and duplicate Chinese provenance fields were localized across 87 text cells. All 201 formulas, numeric cells and cell-style indices are unchanged. Original multilingual source workbooks remain in the local delivery folder.

## English archive scope

This wiki publication edition includes the English documents and their linked figures, modest-size movies, templates and source-reference records. It is larger than the historical code-only GitLab attachment. Large numerical field caches, slicer jobs and supplier originals remain outside the archive. Full numerical replay uses the stated fresh-solver commands; the archive is not a replacement for measured hardware or cell evidence. Original multilingual source files remain unchanged locally.
