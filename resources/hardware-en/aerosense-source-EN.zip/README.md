# AeroSense Hardware source

This archive contains device software and three simulation models.
Extract all files into one directory. Preserve their relative paths.

- 03_software/README.md: firmware, UI, server, tests, and setup.
- 02_simulation/README.md: optics, airflow, and membrane models.
- 07_validation/: measured-data analysis and blank templates.

Each model includes code, required input parameters, and CSV results.
Large generated numerical fields are omitted from this English publication edition.
Read the fresh-reproduction commands below before running plot commands.
Full numerical replay is expensive. The local delivery folder retains saved
fields for fast offline plotting. Do not mix old cached JSON with absent NPZ.
CTB, vendor originals, private configuration, databases, build binaries,
and tool caches are omitted. Linked English media and manual dependencies
are included in this illustrated wiki edition.
The program inputs required for fresh numerical replay are included.

This is the Hardware reproduction attachment, not a Best Software entry.
No physical board, optical, cell, or participant results are claimed.
Keep BOARD_VALIDATED=false until electrical checks pass.
The Wiki repository license remains unchanged. Dependencies retain their
own licenses. Source references remain in the model README files.

## Fresh numerical replay

Run these commands from this archive root in the listed order.
Airflow needs Windows and the .NET Framework C# compiler. No CAD or STL
input is needed. Do not copy cached solve JSON into this fresh source tree.
The CSV files include reference results. Copy any values that you want to
compare before replay, because the scripts replace result CSV files.
Runtime and file hashes are not expected to reproduce byte for byte.

```text
python -m pip install -r 02_simulation/airflow/code/requirements.txt
python -m pip install -r 02_simulation/optics/code/requirements.txt
python -m pip install -r 02_simulation/membrane/code/requirements.txt
python -B 02_simulation/airflow/code/reproduce.py --solve --video
python -B 02_simulation/optics/code/run.py --verify --run --maps --convergence --standard --workers 4
python -B 02_simulation/optics/code/leakage_sweep.py --workers 4
python -B 02_simulation/optics/code/signal_model.py
python -B 02_simulation/optics/code/run.py --plots --video
python -B 02_simulation/optics/code/filter_compare_model.py --geometry --video
python -B 02_simulation/optics/code/validate_filter_comparison.py
python -B 02_simulation/membrane/code/run.py
python -B 02_simulation/membrane/code/integrate_airflow.py
python -B 02_simulation/membrane/code/plot.py
```

The full-replay dependencies were inspected during source packaging.
Packaging did not rerun the expensive MC/CFD solvers. The retained local
fields were used for the verified figure and movie rebuilds.

## English archive scope

This wiki publication edition includes the English documents and their linked figures, modest-size movies, templates and source-reference records. It is larger than the historical code-only GitLab attachment. Large numerical field caches, slicer jobs and supplier originals remain outside the archive. Full numerical replay uses the stated fresh-solver commands; the archive is not a replacement for measured hardware or cell evidence. Original multilingual source files remain unchanged locally.
