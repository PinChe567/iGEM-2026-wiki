Archived ADC and software diagnostics, kept separate from the sodium-fluorescein calibration acquisitions.
Original diagnostic evidence is preserved without changing its contents.
