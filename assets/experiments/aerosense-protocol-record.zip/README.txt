AeroSense experimental protocol record, assembled 2026-10-11.
Open assets/experiments/aerosense-protocols.html in a browser. Print to PDF if needed.
Execution statuses and missing parameters are preserved. Inline diagrams and referenced local images are included. Links to the full wiki are supplementary and require its normal site layout. This is a methods record, not new evidence that specified assays were executed.

Reporter annotation corrected 2026-10-13: the TH recording uses TH-GFP (team label 5137;TH; UAS-mCD8::GFP reporter), not GCaMP6f. The GH146 preparation remains separate. Other execution statuses retain the 2026-10-11 snapshot; consult the live methods page for subsequent updates.
